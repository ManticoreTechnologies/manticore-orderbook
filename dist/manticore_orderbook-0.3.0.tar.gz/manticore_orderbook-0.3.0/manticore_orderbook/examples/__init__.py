"""
Examples package for Manticore OrderBook.
""" 