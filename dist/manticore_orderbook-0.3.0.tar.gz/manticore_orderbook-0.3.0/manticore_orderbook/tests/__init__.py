"""
Test package for Manticore OrderBook.
""" 